package ejemplo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class RectangleTest {

    Rectangle r = new Rectangle();

    @Test
    void testAreaPositivos() {
        assertEquals(20, r.surface(4, 5), "El área de 4 x 5 es 20");
    }

    @Test
    void testAreaConNegativos() { // tiene que devolver -1
        assertEquals(-1, r.surface(-4, 5));
        assertEquals(-1, r.surface(4, -5));
    }

    @Test
    void testAreaConCero() { // devuelve 0
        assertEquals(0, r.surface(0, 5));
    }

    @Test
    void testPerimetroPositivos() {
        assertEquals(18, r.perimeter(4, 5));
    }

    @Test
    void testPerimetroNegativos() {
        assertEquals(-1, r.perimeter(-4, 5));
    }

    @Test
    void testFalloAproposito() {
        // este test tiene que fallar, lo he hecho para ver si JUnit lo detecta
        assertEquals(100, r.surface(2, 2), "Este test falla a propósito para la entrega"); // aquí pongo como que 2x2 da 100, como es mentira hará que el test salga en rojo
    }
}