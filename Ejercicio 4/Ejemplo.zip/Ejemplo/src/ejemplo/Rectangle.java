package ejemplo;

/**
 * Clase que representa un rectángulo y permite calcular su área y perímetro.
 * @author José Manuel López Montesinos
 * @version 1.0
 */
public class Rectangle {

    // Constante extraída
    private static final int DOS = 2;

    /**
     * Constructor por defecto de la clase Rectangle.
     */
    public Rectangle() {
    }

    /**
     * Comprueba que los valores proporcionados sean válidos para los cálculos.
     * @param base La medida de la base a comprobar.
     * @param altura La medida de la altura a comprobar.
     * @return 1 si los valores son válidos, -1 si hay negativos, o 0 si hay ceros.
     */
    private double comprobarValores(double base, double altura) {
        if (base < 0 || altura < 0) {
            return -1;
        }
        if (base == 0 || altura == 0) {
            return 0;
        }
        return 1;
    }

    /**
     * Calcula el área de un rectángulo a partir de su base y su altura.
     * @param base La medida de la base del rectángulo.
     * @param altura La medida de la altura del rectángulo.
     * @return El área calculada. Devuelve -1 si algún parámetro es negativo, 
     * o 0 si algún parámetro es igual a cero.
     */
    public double surface(double base, double altura) {
        double comprobacion = comprobarValores(base, altura);
        if (comprobacion <= 0) {
            return comprobacion; // Retorna -1 o 0
        }
        return base * altura;
    }

    /**
     * Calcula el perímetro de un rectángulo a partir de su base y su altura.
     * @param base La medida de la base del rectángulo.
     * @param altura La medida de la altura del rectángulo.
     * @return El perímetro calculado. Devuelve -1 si algún parámetro es negativo, 
     * o 0 si algún parámetro es igual a cero.
     */
    public double perimeter(double base, double altura) {
        double comprobacion = comprobarValores(base, altura);
        if (comprobacion <= 0) {
            return comprobacion; // Retorna -1 o 0
        }
        return DOS * (base + altura);
    }
}