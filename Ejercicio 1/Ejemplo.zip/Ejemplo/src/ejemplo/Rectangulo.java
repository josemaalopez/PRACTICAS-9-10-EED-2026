package ejemplo;

public class Rectangulo {

    public double area(double base, double altura) {
        if (base < 0 || altura < 0) {
            return -1; // -1 si es negativo
        }
        if (base == 0 || altura == 0) {
            return 0;  // 0 si es cero
        }
        return base * altura;
    }

    public double perimetro(double base, double altura) {
        if (base < 0 || altura < 0) {
            return -1;
        }
        if (base == 0 || altura == 0) { // base o altura son 0
            return 0;
        }
        return 2 * base + 2 * altura;
    }
}